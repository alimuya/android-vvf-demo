package com.pstreets.guice.demo.service;

public interface IGreetingService {

	public String getGreetings();
}
