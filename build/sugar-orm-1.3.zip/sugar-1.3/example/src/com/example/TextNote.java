package com.example;

public class TextNote extends Note {

    public String desc;

    public TextNote() {
    }


}
